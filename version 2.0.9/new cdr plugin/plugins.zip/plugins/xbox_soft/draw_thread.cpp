#include <xtl.h>


extern "C"{
	#include "externals.h"
	#include "gpu.h"
	#include "draw.h"
	#include "prim.h"
	#include "menu.h"
	#include "interp.h"
	#include "swap.h"

	#include "xb_video.h"
}
/*
///
class XbDraw(){
public:
	XbDraw(){
	}
	void init(){

	}
	void update(){
	}
private:
	
}
*/